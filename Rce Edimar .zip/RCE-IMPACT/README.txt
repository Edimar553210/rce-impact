RCE IMPACT — Website estático para GitHub Pages

PRÉ-VISUALIZAÇÃO LOCAL
Abra index.html num navegador. A pasta assets deve permanecer junto do index.html.

PUBLICAR NO GITHUB PAGES
1. Crie um repositório GitHub (por exemplo: rce-impact-site).
2. Carregue todos os ficheiros desta pasta, mantendo a pasta assets.
3. No repositório, abra Settings > Pages.
4. Em Build and deployment, escolha Deploy from a branch.
5. Escolha a branch main e a pasta /(root), depois Save.
6. O GitHub apresentará o endereço público do site.

NOTAS
- Site bilingue PT/EN, com alternância no cabeçalho.
- Formulário atualmente prepara o pedido para copiar. Para envio automático, ligar o email ou WhatsApp oficial da empresa.
- A imagem de marca utiliza o símbolo recortado da referência enviada, sem a designação antiga RCE CLEAN.
- Contactos não foram inventados.
